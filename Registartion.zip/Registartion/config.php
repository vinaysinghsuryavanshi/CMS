<?php
$host  = 'localhost';
$user = 'root';
$pwd ='';
$db = 'cms1';

$con = mysqli_connect($host,$user,$pwd,$db);

if($con)
	echo "";
else
	echo "Failed connection";
?>